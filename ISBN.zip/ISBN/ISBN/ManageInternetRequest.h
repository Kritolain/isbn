//
//  ManageInternetRequest.h
//  Leal
//
//  Created by KUBO on 1/6/16.
//  Copyright © 2016 KUBO. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ManageInternetRequest : NSObject

+(NSString *)organizer:(NSString *)description data:(NSMutableDictionary *)data;

@end
