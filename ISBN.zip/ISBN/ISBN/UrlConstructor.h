//
//  UrlConstructor.h
//  Linker
//
//  Created by KUBO on 11/25/15.
//  Copyright © 2015 KUBO. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UrlConstructor : NSObject

+(NSString *)searchIsbn:(NSMutableDictionary *)datos;

@end
